(() => {
"use strict";

const STORAGE_KEY = "fitqueen.crystal.v1";
const WATER_REFERENCE_ML = 2000; // Referência visual configurável, não recomendação médica.
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const todayKey = () => new Date().toISOString().slice(0, 10);
const dateFromKey = key => new Date(`${key}T12:00:00`);
const fmtDate = (key, options = { day: "2-digit", month: "short", year: "numeric" }) =>
  new Intl.DateTimeFormat("pt-PT", options).format(dateFromKey(key));

const defaultState = () => ({
  version: 1,
  profile: { name: "", goal: "general", units: "metric", reminders: false },
  days: {},
  workoutHistory: [],
  preferences: { waterReference: WATER_REFERENCE_ML }
});

let state = loadState();
let activePlan = "A";
let calendarCursor = new Date();
let selectedDate = todayKey();
let toastTimer;

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultState();
    const parsed = JSON.parse(raw);
    return {
      ...defaultState(),
      ...parsed,
      profile: { ...defaultState().profile, ...(parsed.profile || {}) },
      days: parsed.days && typeof parsed.days === "object" ? parsed.days : {},
      workoutHistory: Array.isArray(parsed.workoutHistory) ? parsed.workoutHistory : []
    };
  } catch (error) {
    console.warn("Não foi possível ler os dados FitQueen:", error);
    return defaultState();
  }
}

function saveState() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    return true;
  } catch (error) {
    console.error("Falha ao guardar dados:", error);
    showToast("Não foi possível guardar. Exporta uma cópia de segurança.");
    return false;
  }
}

function getDay(key = todayKey()) {
  if (!state.days[key]) state.days[key] = { meals: [], waterMl: 0, activities: [] };
  const day = state.days[key];
  if (!Array.isArray(day.meals)) day.meals = [];
  if (!Array.isArray(day.activities)) day.activities = [];
  if (!Number.isFinite(day.waterMl)) day.waterMl = 0;
  return day;
}

function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2400);
}

function escapeText(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
}

function safeId() {
  return (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`);
}

const plans = {
  A: {
    title: "Força geral",
    description: "Uma sessão de corpo inteiro com movimentos básicos. Ajusta a carga e o volume à tua experiência.",
    duration: "25–35 min",
    exercises: [
      ["Agachamento à cadeira", "2 séries · 8–12 repetições", "Peso corporal"],
      ["Flexão inclinada na parede ou banco", "2 séries · 6–10 repetições", "Peso corporal"],
      ["Remada com banda elástica", "2 séries · 8–12 repetições", "Banda leve"],
      ["Ponte de glúteos", "2 séries · 8–12 repetições", "Peso corporal"],
      ["Bird-dog", "2 séries · 6 por lado", "Controlo e estabilidade"]
    ]
  },
  B: {
    title: "Mobilidade e core",
    description: "Movimentos controlados para mobilidade, equilíbrio e estabilidade. Sem pressa e sem forçar amplitudes.",
    duration: "20–30 min",
    exercises: [
      ["Mobilidade torácica", "2 séries · 6 por lado", "Movimento suave"],
      ["Dead bug", "2 séries · 6 por lado", "Controlo"],
      ["Elevação de gémeos", "2 séries · 10–12 repetições", "Apoio se necessário"],
      ["Marcha no lugar", "3 séries · 45 segundos", "Ritmo confortável"],
      ["Alongamento dinâmico", "3–5 minutos", "Sem dor"]
    ]
  },
  C: {
    title: "Resistência",
    description: "Uma opção de atividade cardiovascular moderada. Escolhe uma modalidade de que gostes.",
    duration: "20–30 min",
    exercises: [
      ["Caminhada confortável", "10 minutos", "Exterior ou passadeira"],
      ["Bicicleta ou dança", "5–10 minutos", "Ritmo moderado"],
      ["Caminhada lenta", "5 minutos", "Regresso à calma"]
    ]
  }
};

function navigate(view) {
  const target = $(`#view-${view}`);
  if (!target) return;
  $$(".view").forEach(section => section.classList.toggle("active", section === target));
  $$("[data-view]").forEach(button => button.classList.toggle("active", button.dataset.view === view));
  const titles = { dashboard: "Visão geral", nutrition: "Nutrição", workouts: "Treinos", calendar: "Calendário", progress: "Progresso", profile: "Perfil e definições" };
  $("#pageTitle").textContent = titles[view] || "FitQueen";
  if (view === "nutrition") renderNutrition();
  if (view === "workouts") renderWorkout();
  if (view === "calendar") renderCalendar();
  if (view === "progress") renderProgress();
  if (view === "profile") renderProfile();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function addActivity(key, type, title, detail = "") {
  const day = getDay(key);
  day.activities.push({ id: safeId(), type, title, detail, time: new Date().toISOString() });
  saveState();
}

function openModal(title, formHtml, onSubmit) {
  $("#modalTitle").textContent = title;
  const content = $("#modalContent");
  content.replaceChildren();
  const form = document.createElement("form");
  form.className = "modal-form";
  form.innerHTML = formHtml;
  content.append(form);
  $("#modalBackdrop").hidden = false;
  const first = $("input,select", form);
  if (first) first.focus();
  form.addEventListener("submit", event => {
    event.preventDefault();
    if (onSubmit(form)) {
      $("#modalBackdrop").hidden = true;
      content.replaceChildren();
    }
  });
}
function closeModal() { $("#modalBackdrop").hidden = true; }

function addMeal(existing = null) {
  const isEdit = !!existing;
  openModal(isEdit ? "Editar refeição" : "Adicionar refeição", `
    <label>Nome da refeição<input name="name" required maxlength="70" placeholder="Ex.: Almoço" value="${escapeText(existing?.name || "")}"></label>
    <label>Descrição (opcional)<input name="description" maxlength="120" placeholder="Ex.: arroz, legumes e peixe" value="${escapeText(existing?.description || "")}"></label>
    <label>Tipo<select name="type"><option ${existing?.type === "Pequeno-almoço" ? "selected" : ""}>Pequeno-almoço</option><option ${existing?.type === "Almoço" ? "selected" : ""}>Almoço</option><option ${existing?.type === "Jantar" ? "selected" : ""}>Jantar</option><option ${existing?.type === "Lanche" ? "selected" : ""}>Lanche</option><option ${existing?.type === "Outro" ? "selected" : ""}>Outro</option></select></label>
    <label>Calorias (opcional)<input name="calories" type="number" min="0" max="10000" step="1" placeholder="Estimativa, se souberes" value="${existing?.calories ?? ""}"></label>
    <button class="primary-btn" type="submit">${isEdit ? "Guardar alterações" : "Guardar refeição"}</button>
  `, form => {
    const name = form.elements.name.value.trim();
    const description = form.elements.description.value.trim();
    const caloriesRaw = form.elements.calories.value.trim();
    const calories = caloriesRaw === "" ? null : Number(caloriesRaw);
    if (!name) return false;
    if (calories !== null && (!Number.isFinite(calories) || calories < 0 || calories > 10000)) {
      showToast("Confirma o valor de calorias."); return false;
    }
    const day = getDay(selectedDate === todayKey() ? todayKey() : selectedDate);
    if (isEdit) {
      const item = day.meals.find(meal => meal.id === existing.id);
      if (item) Object.assign(item, { name, description, type: form.elements.type.value, calories });
    } else {
      const meal = { id: safeId(), name, description, type: form.elements.type.value, calories, time: new Date().toISOString() };
      day.meals.push(meal);
      day.activities.push({ id: safeId(), type: "meal", title: `Refeição: ${name}`, detail: meal.type, time: meal.time });
    }
    saveState(); renderAll(); showToast("Refeição guardada.");
    return true;
  });
}

function deleteMeal(id) {
  const day = getDay(selectedDate);
  day.meals = day.meals.filter(meal => meal.id !== id);
  saveState(); renderAll(); showToast("Refeição eliminada.");
}

function addWater(amount, key = todayKey()) {
  const day = getDay(key);
  day.waterMl = Math.max(0, Math.min(10000, day.waterMl + amount));
  day.activities.push({ id: safeId(), type: "water", title: `Água: ${amount > 0 ? "+" : ""}${amount} ml`, detail: "Hidratação", time: new Date().toISOString() });
  saveState(); renderAll(); showToast(amount > 0 ? `${amount} ml registados.` : "Registo atualizado.");
}

function completeWorkout() {
  const plan = plans[activePlan];
  const key = todayKey();
  const record = { id: safeId(), plan: activePlan, title: plan.title, date: key, time: new Date().toISOString() };
  state.workoutHistory.push(record);
  getDay(key).activities.push({ id: safeId(), type: "workout", title: `Treino ${activePlan}: ${plan.title}`, detail: "Sessão concluída", time: record.time });
  saveState(); renderAll(); showToast("Sessão registada. Bom trabalho!");
}

function renderWorkout() {
  const plan = plans[activePlan];
  $("#planEyebrow").textContent = `PLANO ${activePlan}`;
  $("#planTitle").textContent = plan.title;
  $("#planDescription").textContent = plan.description;
  $("#workoutDuration").textContent = `Sessão sugerida: ${plan.duration}`;
  const list = $("#exerciseList");
  list.replaceChildren();
  plan.exercises.forEach((exercise, index) => {
    const row = document.createElement("div");
    row.className = "exercise-row";
    const number = document.createElement("span"); number.className = "exercise-number"; number.textContent = String(index + 1).padStart(2, "0");
    const info = document.createElement("div");
    const name = document.createElement("b"); name.textContent = exercise[0];
    const detail = document.createElement("small"); detail.textContent = exercise[1];
    info.append(name, detail);
    const meta = document.createElement("span"); meta.className = "exercise-meta"; meta.textContent = exercise[2];
    row.append(number, info, meta); list.append(row);
  });
  $$(".workout-tab").forEach(button => button.classList.toggle("active", button.dataset.plan === activePlan));
}

function renderDashboard() {
  const key = todayKey(), day = getDay(key);
  const name = state.profile.name.trim() || "bem-vinda";
  $("#welcomeName").textContent = name;
  $("#sidebarName").textContent = state.profile.name.trim() || "O teu espaço";
  $("#avatarInitial").textContent = (state.profile.name.trim()[0] || "F").toUpperCase();
  $("#headerDate").textContent = fmtDate(key, { weekday: "short", day: "numeric", month: "short" });
  $("#dashboardDate").textContent = fmtDate(key, { weekday: "long", day: "numeric", month: "long" });
  $("#waterValue").textContent = (day.waterMl / 1000).toFixed(2).replace(".", ",");
  $("#waterProgress").style.width = `${Math.min(100, day.waterMl / WATER_REFERENCE_ML * 100)}%`;
  $("#mealCount").textContent = day.meals.length;
  $("#mealHint").textContent = day.meals.length ? "As tuas refeições estão registadas." : "Regista uma refeição quando quiseres.";
  const workoutsToday = state.workoutHistory.filter(item => item.date === key).length;
  $("#workoutStatus").textContent = workoutsToday ? "Concluído" : "Livre";
  $("#workoutHint").textContent = workoutsToday ? `${workoutsToday} sessão(ões) registada(s).` : "Movimento também pode ser descanso.";
  $("#streakValue").textContent = activeDayCount();
  const activity = $("#todayActivity"); activity.replaceChildren();
  const items = [...day.activities].sort((a,b) => new Date(b.time) - new Date(a.time)).slice(0, 5);
  if (!items.length) activity.innerHTML = '<div class="empty-state">Ainda não há atividades registadas.</div>';
  items.forEach(item => activity.append(makeActivityRow(item)));
}

function makeActivityRow(item) {
  const row = document.createElement("div"); row.className = "activity-row";
  const icon = document.createElement("span"); icon.className = "activity-symbol"; icon.textContent = item.type === "workout" ? "✦" : item.type === "meal" ? "♧" : item.type === "water" ? "◌" : "·";
  const info = document.createElement("div"); const title = document.createElement("b"); title.textContent = item.title;
  const detail = document.createElement("small"); detail.textContent = item.detail || new Date(item.time).toLocaleTimeString("pt-PT", { hour: "2-digit", minute: "2-digit" });
  info.append(title, detail); row.append(icon, info); return row;
}

function renderNutrition() {
  const key = selectedDate, day = getDay(key);
  $("#nutritionMeals").textContent = day.meals.length;
  $("#nutritionWater").textContent = `${day.waterMl.toLocaleString("pt-PT")} ml`;
  $("#mealDateLabel").textContent = fmtDate(key);
  $("#waterPercent").textContent = `${Math.round(Math.min(100, day.waterMl / WATER_REFERENCE_ML * 100))}%`;
  $("#nutritionWaterProgress").style.width = `${Math.min(100, day.waterMl / WATER_REFERENCE_ML * 100)}%`;
  const list = $("#mealList"); list.replaceChildren();
  if (!day.meals.length) { list.innerHTML = '<div class="empty-state">Ainda não existem refeições neste dia.</div>'; return; }
  day.meals.forEach(meal => {
    const row = document.createElement("div"); row.className = "meal-row";
    const icon = document.createElement("span"); icon.className = "activity-symbol"; icon.textContent = "♧";
    const info = document.createElement("div"); const title = document.createElement("b"); title.textContent = meal.name;
    const detail = document.createElement("small"); detail.textContent = `${meal.type}${meal.description ? " · " + meal.description : ""}`;
    info.append(title, detail);
    const calories = document.createElement("span"); calories.className = "meal-cal"; calories.textContent = meal.calories == null ? "—" : `${meal.calories} kcal*`;
    const actions = document.createElement("div"); actions.className = "row-actions";
    const edit = document.createElement("button"); edit.className = "mini-btn"; edit.textContent = "Editar"; edit.addEventListener("click", () => addMeal(meal));
    const del = document.createElement("button"); del.className = "mini-btn"; del.textContent = "×"; del.setAttribute("aria-label", "Eliminar refeição"); del.addEventListener("click", () => deleteMeal(meal.id));
    actions.append(edit, del); row.append(icon, info, calories, actions); list.append(row);
  });
}

function renderCalendar() {
  const year = calendarCursor.getFullYear(), month = calendarCursor.getMonth();
  $("#monthTitle").textContent = new Intl.DateTimeFormat("pt-PT", { month: "long", year: "numeric" }).format(calendarCursor);
  const first = new Date(year, month, 1);
  const offset = (first.getDay() + 6) % 7;
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const previousDays = new Date(year, month, 0).getDate();
  const grid = $("#calendarGrid"); grid.replaceChildren();
  for (let i = 0; i < 42; i++) {
    let date, muted = false;
    if (i < offset) { date = new Date(year, month - 1, previousDays - offset + i + 1); muted = true; }
    else if (i >= offset + daysInMonth) { date = new Date(year, month + 1, i - offset - daysInMonth + 1); muted = true; }
    else date = new Date(year, month, i - offset + 1);
    const key = date.toISOString().slice(0,10), day = state.days[key];
    const button = document.createElement("button"); button.className = "calendar-day";
    if (muted) button.classList.add("muted-day");
    if (key === todayKey()) button.classList.add("today");
    if (key === selectedDate) button.classList.add("selected");
    const number = document.createElement("span"); number.className = "day-number"; number.textContent = date.getDate(); button.append(number);
    if (day) {
      const dots = document.createElement("span"); dots.className = "day-dots";
      if (day.meals?.length) { const dot = document.createElement("i"); dot.className = "dot dot-meal"; dots.append(dot); }
      if (state.workoutHistory.some(item => item.date === key)) { const dot = document.createElement("i"); dot.className = "dot dot-workout"; dots.append(dot); }
      if (day.waterMl > 0) { const dot = document.createElement("i"); dot.className = "dot dot-water"; dots.append(dot); }
      button.append(dots);
    }
    button.addEventListener("click", () => { selectedDate = key; renderCalendar(); renderNutrition(); });
    grid.append(button);
  }
  $("#selectedDateTitle").textContent = `Registos — ${fmtDate(selectedDate)}`;
  const content = $("#selectedDayContent"); content.replaceChildren();
  const chosen = state.days[selectedDate];
  const events = chosen?.activities || [];
  if (!events.length) content.innerHTML = '<div class="empty-state">Sem atividades registadas nesta data.</div>';
  events.slice().sort((a,b) => new Date(b.time) - new Date(a.time)).forEach(item => content.append(makeActivityRow(item)));
}

function activeDayCount() {
  return Object.values(state.days).filter(day => (day.activities?.length || 0) > 0 || (day.meals?.length || 0) > 0 || (day.waterMl || 0) > 0).length;
}

function renderProgress() {
  $("#totalWorkouts").textContent = state.workoutHistory.length;
  $("#totalMeals").textContent = Object.values(state.days).reduce((sum, day) => sum + (day.meals?.length || 0), 0);
  $("#activeDays").textContent = activeDayCount();
  const bars = $("#weeklyBars"); bars.replaceChildren();
  const now = new Date(); const labels = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(now); d.setDate(now.getDate() - i);
    const key = d.toISOString().slice(0,10), day = state.days[key];
    const count = (day?.activities?.length || 0) + (day?.meals?.length || 0) + (state.workoutHistory.some(w => w.date === key) ? 1 : 0);
    labels.push({ label: new Intl.DateTimeFormat("pt-PT", { weekday: "short" }).format(d).replace(".", ""), count });
  }
  const max = Math.max(1, ...labels.map(x => x.count));
  labels.forEach(item => {
    const col = document.createElement("div"); col.className = "bar-column";
    const count = document.createElement("b"); count.textContent = item.count;
    const track = document.createElement("div"); track.className = "bar-track";
    const fill = document.createElement("div"); fill.className = "bar-fill"; fill.style.height = `${item.count / max * 100}%`; track.append(fill);
    const label = document.createElement("small"); label.textContent = item.label;
    col.append(count, track, label); bars.append(col);
  });
  const history = $("#recentHistory"); history.replaceChildren();
  const all = Object.entries(state.days).flatMap(([date, day]) => (day.activities || []).map(item => ({ ...item, date }))).sort((a,b) => new Date(b.time) - new Date(a.time)).slice(0,12);
  if (!all.length) history.innerHTML = '<div class="empty-state">O teu histórico aparecerá aqui.</div>';
  all.forEach(item => {
    const row = makeActivityRow(item);
    const date = document.createElement("small"); date.textContent = fmtDate(item.date); date.style.color = "var(--muted)";
    row.append(date); history.append(row);
  });
}

function renderProfile() {
  $("#profileName").value = state.profile.name || "";
  $("#profileGoal").value = state.profile.goal || "general";
  $("#profileUnits").value = state.profile.units || "metric";
  $("#profileReminders").checked = !!state.profile.reminders;
}

function renderAll() {
  renderDashboard();
  if ($("#view-nutrition").classList.contains("active")) renderNutrition();
  if ($("#view-workouts").classList.contains("active")) renderWorkout();
  if ($("#view-calendar").classList.contains("active")) renderCalendar();
  if ($("#view-progress").classList.contains("active")) renderProgress();
}

function exportBackup() {
  const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a"); a.href = url; a.download = `fitqueen-backup-${todayKey()}.json`; a.click();
  URL.revokeObjectURL(url); showToast("Cópia de segurança exportada.");
}
function exportData() {
  const rows = [["Data","Tipo","Descrição","Detalhe"]];
  Object.entries(state.days).forEach(([date, day]) => {
    (day.activities || []).forEach(item => rows.push([date, item.type, item.title, item.detail || ""]));
  });
  const csv = rows.map(row => row.map(value => `"${String(value).replace(/"/g, '""')}"`).join(";")).join("\r\n");
  const blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = `fitqueen-historico-${todayKey()}.csv`; a.click(); URL.revokeObjectURL(url);
}
function importBackup(file) {
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const imported = JSON.parse(reader.result);
      if (!imported || typeof imported !== "object" || !imported.days || typeof imported.days !== "object") throw new Error("Formato inválido");
      state = { ...defaultState(), ...imported, profile: { ...defaultState().profile, ...(imported.profile || {}) } };
      saveState(); renderAll(); renderProfile(); showToast("Cópia de segurança importada.");
    } catch (error) { showToast("Não foi possível importar este ficheiro."); }
  };
  reader.readAsText(file);
}

function init() {
  $("#todayLabel").textContent = "O TEU ESPAÇO DE BEM-ESTAR";
  $$("[data-view]").forEach(button => button.addEventListener("click", () => navigate(button.dataset.view)));
  $$("[data-go]").forEach(button => button.addEventListener("click", () => navigate(button.dataset.go)));
  $("#quickAddBtn").addEventListener("click", () => addMeal());
  $("#addMealBtn").addEventListener("click", () => { selectedDate = todayKey(); addMeal(); });
  $$("[data-action='water']").forEach(button => button.addEventListener("click", () => addWater(250)));
  $$("[data-water]").forEach(button => button.addEventListener("click", () => addWater(Number(button.dataset.water), selectedDate)));
  $$(".workout-tab").forEach(button => button.addEventListener("click", () => { activePlan = button.dataset.plan; renderWorkout(); }));
  $("#completeWorkoutBtn").addEventListener("click", completeWorkout);
  $("#prevMonth").addEventListener("click", () => { calendarCursor.setMonth(calendarCursor.getMonth() - 1); renderCalendar(); });
  $("#nextMonth").addEventListener("click", () => { calendarCursor.setMonth(calendarCursor.getMonth() + 1); renderCalendar(); });
  $("#modalClose").addEventListener("click", closeModal);
  $("#modalBackdrop").addEventListener("click", event => { if (event.target === $("#modalBackdrop")) closeModal(); });
  document.addEventListener("keydown", event => { if (event.key === "Escape") closeModal(); });
  $("#profileForm").addEventListener("submit", event => {
    event.preventDefault();
    state.profile = { name: $("#profileName").value.trim(), goal: $("#profileGoal").value, units: $("#profileUnits").value, reminders: $("#profileReminders").checked };
    saveState(); renderDashboard(); showToast("Perfil atualizado.");
  });
  $("#backupBtn").addEventListener("click", exportBackup);
  $("#exportBtn").addEventListener("click", exportData);
  $("#importFile").addEventListener("change", event => { if (event.target.files[0]) importBackup(event.target.files[0]); event.target.value = ""; });
  $("#resetBtn").addEventListener("click", () => {
    if (confirm("Queres apagar todos os dados FitQueen guardados neste dispositivo? Esta ação não pode ser desfeita. Exporta uma cópia antes, se precisares.")) {
      state = defaultState(); saveState(); selectedDate = todayKey(); renderAll(); renderProfile(); showToast("Dados locais apagados.");
    }
  });
  renderAll();
  if ("serviceWorker" in navigator && location.protocol !== "file:") {
    window.addEventListener("load", () => navigator.serviceWorker.register("./service-worker.js").catch(error => console.warn("Service Worker indisponível:", error)));
  }
}
document.addEventListener("DOMContentLoaded", init);
})();